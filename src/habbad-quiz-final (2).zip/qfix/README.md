# Habbad Quiz — version mise à jour

Projet Vite + React. Les 224 questions du fichier `src/questions.json` sont les seules questions utilisées.

## Installation et lancement

```bash
npm install
npm run dev
```

## Déploiement

```bash
npm run build
```

Sur Vercel : Framework Vite, commande `npm run build`, dossier de sortie `dist`.
